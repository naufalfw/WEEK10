package week10;

public abstract class BangunDatar {

    // Metode abstrak untuk menghitung luas tanpa parameter
    public abstract double luas();

    // Metode abstrak untuk menghitung luas dengan parameter
    public abstract double luas(int a);

    // Metode abstrak untuk menghitung keliling tanpa parameter
    public abstract double keliling();

    // Metode abstrak untuk menghitung keliling dengan parameter
    public abstract double keliling(int a);
}
